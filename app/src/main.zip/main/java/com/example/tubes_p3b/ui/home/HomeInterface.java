package com.example.tubes_p3b.ui.home;

import android.view.View;

public interface HomeInterface {
    public void onClick(View v);
}
