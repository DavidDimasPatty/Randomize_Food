package com.example.tubes_p3b;

import android.view.View;

public interface InterDisplay {
    void onPause();
    void onResume();
}
