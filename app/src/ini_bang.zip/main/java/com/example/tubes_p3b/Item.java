package com.example.tubes_p3b;

public interface Item  {

}
