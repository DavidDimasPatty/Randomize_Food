package com.example.tubes_p3b.ui.slideshow;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tubes_p3b.FragmentListener;
import com.example.tubes_p3b.Person;
import com.example.tubes_p3b.PersonListAdapter;
import com.example.tubes_p3b.R;
import com.example.tubes_p3b.ui.detail.DetailFragment;
import com.example.tubes_p3b.ui.home.HomeFragment;

import java.util.ArrayList;

public class SlideshowFragment extends Fragment  implements AdapterView.OnItemClickListener {

    private SlideshowViewModel slideshowViewModel;

    private FragmentListener listener;

    private DetailFragment fragment4;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private static ArrayList<Person> peopleList;
    private PersonListAdapter adapter;
    private int x;
    private TextView settag;
    private ListView mListView;
    private FragmentManager fragmentManager;

    public SlideshowFragment (){

    }
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                ViewModelProviders.of(this).get(SlideshowViewModel.class);
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);
        this.mListView = root.findViewById(R.id.listView);
       mListView.setOnItemClickListener(this);
        Person john = new Person("Nasgor","Nasi, Bawang","Male");
        Person steve = new Person("Steve","08-03-1987","Male" );
        Person stacy = new Person("Stacy","11-15-2000","Female");
        Person ashley = new Person("Ashley","07-02-1999","Female");
        Person matt = new Person("Matt","03-29-2001","Male" );
        Person matt2 = new Person("Matt2","03-29-2001","Male" );
        Person matt3 = new Person("Matt3","03-29-2001","Male" );
        Person matt4 = new Person("Matt4","03-29-2001","Male" );






        //Add the Person objects to an ArrayList

       this.peopleList = new ArrayList<>();
        peopleList.add(john);
        peopleList.add(steve);
        peopleList.add(stacy);
        peopleList.add(ashley);
        peopleList.add(matt);
        peopleList.add(matt2);
        peopleList.add(matt3);
        peopleList.add(matt4);
        peopleList.add(john);
        peopleList.add(steve);
        peopleList.add(stacy);
        peopleList.add(ashley);
        peopleList.add(matt);
        peopleList.add(matt2);




        this.adapter = new PersonListAdapter(getContext(), R.layout.adapter_view_layout, peopleList);
        mListView.setAdapter(adapter);


        return root;
    }

    public void array(String a,String b,String c){
        this.adapter.setNotifyOnChange(true);
       this.mListView.setAdapter(adapter);
    }

    public static SlideshowFragment newInstance (String a,String b,String c){
        SlideshowFragment fragment=new SlideshowFragment();
        Bundle args=new Bundle();
        args.putString("title1",a);
        args.putString("bahan2",b);
        args.putString("resto3",c);
        fragment.setArguments(args);
        return fragment;
    }
    public void onAttach(Context context){
        super.onAttach(context);
        if(context instanceof FragmentListener){
            this.listener=(FragmentListener) context;
        }
        else{
            throw new ClassCastException(context.toString()+"must implement FragmentListener");
        }
    }

    public void onItemClick(AdapterView<?> l, View v, int position, long id) {
        this.listener.getItemList(position,this.peopleList);

    }




}