package com.example.tubes_p3b;

import android.view.View;
import android.widget.AdapterView;

import java.util.ArrayList;

public interface FragmentListener {
    void changePage(int page);
    String getItemList(int page, ArrayList<Person> a);
}
