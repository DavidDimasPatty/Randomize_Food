package com.example.tubes_p3b.ui.detail;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.tubes_p3b.FragmentListener;
import com.example.tubes_p3b.Person;
import com.example.tubes_p3b.PersonListAdapter;
import com.example.tubes_p3b.R;
import com.example.tubes_p3b.ui.gallery.GalleryFragment;
import com.example.tubes_p3b.ui.gallery.GalleryViewModel;

import java.util.ArrayList;

public class DetailFragment extends Fragment  {

    public DetailFragment (){

    }
    private DetailViewModel DetailViewModel;
    private FragmentListener listener;
    private TextView tag;
    private TextView bahan;
    private TextView judul;
    private TextView resto;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        DetailViewModel =
                ViewModelProviders.of(this).get(DetailViewModel.class);

        View root = inflater.inflate(R.layout.detail_makanan, container, false);
        this.tag=root.findViewById(R.id.tag);
        this.bahan=root.findViewById(R.id.bahan);
        this.judul=root.findViewById(R.id.judul);
        this.resto=root.findViewById(R.id.resto);
        this.tag.setText(this.getArguments().getString("title",""));
        this.bahan.setText(this.getArguments().getString("bahan",""));
        this.judul.setText(this.getArguments().getString("title",""));
        this.resto.setText(this.getArguments().getString("resto",""));


        return root;
    }
    public static DetailFragment newInstance (String title,String bahan,String resto){
        DetailFragment fragment=new DetailFragment();
        Bundle args=new Bundle();
        args.putString("title",title);
        args.putString("bahan",bahan);
        args.putString("resto",resto);
        fragment.setArguments(args);
        return fragment;
    }

    public void onAttach(Context context){
        super.onAttach(context);
        if(context instanceof FragmentListener){
            this.listener=(FragmentListener) context;
        }
        else{
            throw new ClassCastException(context.toString()+"must implement FragmentListener");
        }
    }

    public void setMessage (String message){

        this.tag.setText(message);
    }



}
