package com.example.tubes_p3b;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Menu;

import com.example.tubes_p3b.ui.detail.DetailFragment;
import com.example.tubes_p3b.ui.gallery.GalleryFragment;
import com.example.tubes_p3b.ui.home.HomeFragment;

import com.example.tubes_p3b.ui.slideshow.SlideshowFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements FragmentListener{

    private AppBarConfiguration mAppBarConfiguration;
    private HomeFragment fragment1;
    private  GalleryFragment fragment3;
    private SlideshowFragment fragment2;

    private  DetailFragment fragment4;
    private FragmentManager fragmentManager;
    private PersonListAdapter listAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               openDialog();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        this.fragment1=HomeFragment.newInstance();
        this.fragment2=SlideshowFragment.newInstance(null,null,null);
          this.fragment3=GalleryFragment.newInstance();
        this.fragment4= DetailFragment.newInstance(null,null,null);
        this.fragmentManager=this.getSupportFragmentManager();
        FragmentTransaction ft=this.fragmentManager.beginTransaction();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public void changePage(int page){
        FragmentTransaction ft=this.fragmentManager.beginTransaction();


        if(page==1){
            if(this.fragment1.isAdded()){
                ft.show(this.fragment1);
            }

            else{
                ft.add(R.id.fragment_container,this.fragment1).addToBackStack(null);
            }

            if(this.fragment2.isAdded()){
                ft.hide(this.fragment2);
            }


        }
        else if(page==2){
            if(this.fragment2.isAdded()){
                ft.show(this.fragment2);
            }
            else{
                ft.add(R.id.fragment_container,this.fragment2).addToBackStack(null);
            }

        }

        else if(page==3){
            if(this.fragment3.isAdded()){
                ft.hide(this.fragment1);
                ft.hide(this.fragment2);
            }
            else{
                ft.add(R.id.fragment_container,this.fragment3);

            }
        }


        ft.commit();
    }

    @Override
    public String getItemList(int page, ArrayList<Person> a) {
        String name = a.get(page).getName();
        String bahan = a.get(page).getBahan();
        String resto = a.get(page).getResto();
        Log.d("tag", name);
        FragmentTransaction ft=this.fragmentManager.beginTransaction();

        this.fragment4=DetailFragment.newInstance(name,bahan,resto);
        ft.replace(R.id.fragment_container,this.fragment4).commit();


        return name;

    }


    public void openDialog(){
        ExampleDialog exampleDialog=new ExampleDialog();
        exampleDialog.show(getSupportFragmentManager(),"example dialog");
    }





}