package com.example.tubes_p3b;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.transition.Slide;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.tubes_p3b.R;
import com.example.tubes_p3b.ui.slideshow.SlideshowFragment;

import java.util.ArrayList;

public class ExampleDialog extends AppCompatDialogFragment {

    private FragmentListener listener;
    private EditText editTextU;
    private  EditText editpw;
    private  EditText editbahan;
    private SlideshowFragment slide;
    private Person person;



    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());
        LayoutInflater inflater= getActivity().getLayoutInflater();
        View view=inflater.inflate(R.layout.layout_dialog,null);
        builder.setView(view).setTitle("Tambah Makanan").setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).setPositiveButton("oke", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String username=editTextU.getText().toString();
                String password=editpw.getText().toString();
                String bahan=editbahan.getText().toString();
                SlideshowFragment.newInstance(username,password,bahan);

            }
        });
    editpw=view.findViewById(R.id.edit_password);
    editTextU=view.findViewById(R.id.edit_username);
    editbahan=view.findViewById(R.id.edit_bahan);
    return builder.create();

    }



}
